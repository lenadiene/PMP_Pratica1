package com.example.weatherapp.model

data class User(val name: String, val email: String)